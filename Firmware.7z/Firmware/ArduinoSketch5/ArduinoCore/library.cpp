/*
 * ArduinoCore.cpp
 *
 * Created: 4/15/2017 10:19:10 PM
 * Author : rohan
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

