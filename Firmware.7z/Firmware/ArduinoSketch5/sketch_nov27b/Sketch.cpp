﻿/*Begining of Auto generated code by Atmel studio */
#include <Arduino.h>

/*End of auto generated code by Atmel studio */


#include <LiquidCrystal.h>
#include <avr/eeprom.h>
#include <SoftwareSerial.h>
//Beginning of Auto generated function prototypes by Atmel Studio
void gsm_loop();
void SendMessage(int l);
void ph_loop();
void flow_setup();
void flow_loop();
void pulseCounter();
void menu_main(int nSelected);
void submenu_main(int nSelected);
void update(int p);
byte keypad();
void change_password();
void change_capacity();
void change_mob();
void handler_sub();
void handler_main();
ISR(TIMER2_OVF_vect );
//End of Auto generated function prototypes by Atmel Studio


// initialize the library with the numbers of the interface pins
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);
unsigned int tcnt2;
int toggle=0;
typedef struct settings{
char pass[4];
char mobile_number[10];
char capacity[4];
}Attributes;
int j=0,k=0,l=0,m=0,up=0,down=0,up1=0,down1=0;
Attributes r,s;
byte h=0,v=0;    
const unsigned long period=50;  
unsigned long kdelay=0;         
const byte rows=4;             
const byte  columns=4;            
const byte Output[rows]={38,40,42,44}; 
const byte Input[columns]={46,48,30,32};

const byte phpin= A0;
byte statusLed    = 13;

byte sensorInterrupt = 0;  // 0 = digital pin 2'

float flowRate;
unsigned int flowMilliLitres;
unsigned long totalMilliLitres;

unsigned long oldTime;
// The hall-effect flow sensor outputs approximately 4.5 pulses per second per
// litre/minute of flow.
float calibrationFactor = 7.5;

float ro;
float p;
float po;
unsigned int ml=0;
volatile byte pulseCount;  
unsigned int c=0,d=0,e=0;
SoftwareSerial mySerial(10, 9);


void gsm_loop()
{
  unsigned int y=0;
  
  
  //Serial.println(ml);
  y=.001*totalMilliLitres;
  if (y>=ml && c==0){
     c=1;
     SendMessage(100);
  }else if (y>=0.8*ml && d==0){
     d=1;
     SendMessage(80);
}else if (y>=0.5*ml && e==0)
     {e=1;
    SendMessage(50);
     }
 
}


 void SendMessage(int l)
{
  if(l==100){
  mySerial.println("AT+CMGF=1");    //Sets the GSM Module in Text Mode
  delay(1000);  // Delay of 1000 milli seconds or 1 second
  mySerial.print("AT+CMGS=\"+91");
  for(int k=0 ; k<10 ;++k){
  mySerial.print(s.mobile_number[k]);
  }
  mySerial.println("\"\r"); // Replace x with mobile number
  delay(1000);
  mySerial.print("You've crossed 100 % of your limit & now you'll be charged 1.5 times/litre ");
  delay(100);
   mySerial.println((char)26);// ASCII code of CTRL+Z
  delay(1000);
  }else{
  mySerial.println("AT+CMGF=1");    //Sets the GSM Module in Text Mode
  delay(1000);  // Delay of 1000 milli seconds or 1 second
  mySerial.print("AT+CMGS=\"+91");
  for(int k=0 ; k<10 ;++k){
  mySerial.print(s.mobile_number[k]);
  }
  mySerial.println("\"\r"); // Replace x with mobile number
  delay(1000);
  mySerial.print("You've crossed ");
  mySerial.print(l);
  mySerial.println("% of limit");// The SMS text you want to send
  delay(100);
   mySerial.println((char)26);// ASCII code of CTRL+Z
  delay(1000);
  }
}



void ph_loop() {
  // put your main code here, to run repeatedly:
  ro = analogRead(phpin);
  float t = analogRead(A2);
  p=5/1024.0 * ro;
  if(po>=7)
  po=7 +((2.593-p)/0.18229); //- 0.4
  else
  po=7 +((2.593-p)/0.18229) -0.4;
  
  delay(1000);
}


void flow_setup()
{
  
  //Serial.begin(9600);
  
 
 
  pinMode(statusLed, OUTPUT);
  digitalWrite(statusLed, LOW);  
  

  pulseCount        = 0;
  flowRate          = 0.0;
  flowMilliLitres   = 0;
  totalMilliLitres  = 0;
  oldTime           = 0;

  
  attachInterrupt(digitalPinToInterrupt(20), pulseCounter, FALLING);
}

void flow_loop()
{
  
   if((millis() - oldTime) > 1000)    
   { 
    detachInterrupt(digitalPinToInterrupt(20));
        
    flowRate = ((1000.0 / (millis() - oldTime)) * pulseCount) / calibrationFactor;
    
    oldTime = millis();
    
    flowMilliLitres = (flowRate / 60) * 1000;
    
    totalMilliLitres += flowMilliLitres;
      
    unsigned int frac;
    
    //Serial.print("Flow rate: ");
    //Serial.print(int(flowRate));  
    //Serial.print(".");             
    frac = (flowRate - int(flowRate)) * 10;
    //Serial.print(frac, DEC) ;      Serial.print("L/min");
    // Print the number of litres flowed in this second
    //Serial.print("  Current Liquid Flowing: ");             // Output separator
    //Serial.print(flowMilliLitres);
    //Serial.print("mL/Sec");

    // Print the cumulative total of litres flowed since starting
    //Serial.print("  Output Liquid Quantity: ");             // Output separator
    //Serial.print(totalMilliLitres);
    //Serial.println("mL"); 

    // Reset the pulse counter so we can start incrementing again
    pulseCount = 0;
    
    // Enable the interrupt again now that we've finished sending output
    attachInterrupt(digitalPinToInterrupt(20), pulseCounter, FALLING);
  
  }
}

/*
Insterrupt Service Routine
 */
void pulseCounter()
{
  // Increment the pulse counter
  pulseCount++;
}
void menu_main(int nSelected=0){
char* menu[2]={"Make Change","Reset"};
lcd.clear();
for(int k=0;k<2;k++){
if(k==nSelected){
 lcd.setCursor(0,k);
lcd.print(">");
lcd.setCursor(1,k);
lcd.print(menu[k]);

}else{
lcd.setCursor(0,k);
lcd.print(menu[k]);
}
}




}
void submenu_main(int nSelected=0){
char* menu[4]={"Change Password","Change Capacity","Change Number","Back"};
lcd.clear();
for(int k=0;k<2;k++){
if(k==nSelected){
 lcd.setCursor(0,k);
lcd.print(">");
lcd.setCursor(1,k);
lcd.print(menu[k]);

}else{
lcd.setCursor(0,k);
lcd.print(menu[k]);
}
}
if(nSelected==2){
lcd.setCursor(-4,2);
lcd.print(">");
lcd.setCursor(-3,2);
lcd.print(menu[2]);
}else{
lcd.setCursor(-4,2);
lcd.print(menu[2]);
}
if(nSelected==3){
lcd.setCursor(-4,3);
lcd.print(">");
lcd.setCursor(-3,3);
lcd.print(menu[3]);
}else{
lcd.setCursor(-4,3);
lcd.print(menu[3]);
}
}


void update(int p){
submenu_main(p);
}

byte keypad() 
{
 static bool no_press_flag=0;   
  for(byte x=0;x<columns;x++)   
  {
     if (digitalRead(Input[x])==HIGH);  
     else
     break;
     if(x==(columns-1))    
     {
      no_press_flag=1;
      h=0;
      v=0;
     }
  }
  if(no_press_flag==1)  
  {
    for(byte r=0;r<rows;r++) 
    digitalWrite(Output[r],LOW);
    for(h=0;h<columns;h++)  
    {
      if(digitalRead(Input[h])==HIGH) 
      continue;
      else          {
          for (v=0;v<rows;v++)   
          {
          digitalWrite(Output[v],HIGH);   
          if(digitalRead(Input[h])==HIGH)  
          {
            no_press_flag=0;                
            for(byte w=0;w<rows;w++) 
            digitalWrite(Output[w],LOW);
            return v*4+h;   
          }
          }
      }
    }
  }
 return 50;
}

void change_password(){
  eeprom_read_block((void*)&s, (void*)0, sizeof(s));
  lcd.clear();
  k=0;m=0;
lcd.setCursor(0,0);
lcd.print("EnterOldPassword");
lcd.setCursor(0,1);
 for(int i=0;i<10;i++)
   r.mobile_number[i]=s.mobile_number[i];
  for(int i=0;i<4;i++)
   r.pass[i]='0';
  for(int i=0;i<4;i++)
   r.capacity[i]=s.capacity[i];
 
 while(1){
 
   if(m==4)
  break;
  if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
    switch (keypad())  //switch used to specify which button
   {
            case 0:
            r.pass[m]='1';
            lcd.print('*');
            m++;
       break;  
            case 1:
            r.pass[m]='2';
            lcd.print('*');
            m++;
       break;
            case 2:
            r.pass[m]='3';
            lcd.print('*');
            m++;
       break;
            case 4:
            r.pass[m]='4';
            lcd.print('*');
            m++;
       break;
            case 5:
            r.pass[m]='5';
            lcd.print('*');
            m++;
       break;
            case 6:
            r.pass[m]='6';
            lcd.print('*');
            m++;
       break;
            case 8:
            r.pass[m]='7';
            lcd.print('*');
            m++;
       break;
            case 9:
            r.pass[m]='8';
            lcd.print('*');
            m++;
       break;
            case 10:
            r.pass[m]='9';
            lcd.print('*');
            m++;
       break;
            case 12:
            r.pass[m]='*';
            lcd.print('*');
            m++;
       break;
            case 13:
            r.pass[m]='0';
            lcd.print('*');
            m++;
       break;
            case 14:
            r.pass[m]='#';
            lcd.print('*');
            m++;
       break;
            default:
            ;
}       
  }
 }
 lcd.clear();
  k=0;m=0;
lcd.setCursor(0,0);
 
 for(int i=0;i<4 ;i++){
 if(s.pass[i]!=r.pass[i]){
   k=1;
   break;
 }
 }
 m=0;
 if(k==1){
   lcd.clear();
  lcd.print("WrongPassword");
   delay(2000);
 menu_main();
 handler_main();
 }else{
   lcd.print("EnterNewPassword");
lcd.setCursor(0,1);
  while(1){
   if(m==4)
  break;
  if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
    switch (keypad())  //switch used to specify which button
   {
            case 0:
            r.pass[m]='1';
            lcd.print('*');
            m++;
       break;  
            case 1:
            r.pass[m]='2';
            lcd.print('*');
            m++;
       break;
            case 2:
            r.pass[m]='3';
            lcd.print('*');
            m++;
       break;
            case 4:
            r.pass[m]='4';
            lcd.print('*');
            m++;
       break;
            case 5:
            r.pass[m]='5';
            lcd.print('*');
            m++;
       break;
            case 6:
            r.pass[m]='6';
            lcd.print('*');
            m++;
       break;
            case 8:
            r.pass[m]='7';
            lcd.print('*');
            m++;
       break;
            case 9:
            r.pass[m]='8';
            lcd.print('*');
            m++;
       break;
            case 10:
            r.pass[m]='9';
            lcd.print('*');
            m++;
       break;
            case 12:
            r.pass[m]='*';
            lcd.print('*');
            m++;
       break;
            case 13:
            r.pass[m]='0';
            lcd.print('*');
            m++;
       break;
            case 14:
            r.pass[m]='#';
            lcd.print('*');
            m++;
       break;
            default:
            ;
}       
  }
 }
         eeprom_write_block((const void*)&r, (void*)0, sizeof(r));
         lcd.clear();
         lcd.print("Password Changed");
         delay(2000);
 }
 
 
}



void change_capacity(){
  eeprom_read_block((void*)&s, (void*)0, sizeof(s));
  lcd.clear();
  k=0;m=0;
lcd.setCursor(0,0);
lcd.print("Enter Password");
lcd.setCursor(0,1);
 for(int i=0;i<10;i++)
   r.mobile_number[i]=s.mobile_number[i];
  for(int i=0;i<4;i++)
   r.pass[i]=s.pass[i];
  for(int i=0;i<4;i++)
   r.capacity[i]='0';
 
 while(1){
 
   if(m==4)
  break;
  if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
    switch (keypad())  //switch used to specify which button
   {
            case 0:
            r.pass[m]='1';
            lcd.print('*');
            m++;
       break;  
            case 1:
            r.pass[m]='2';
            lcd.print('*');
            m++;
       break;
            case 2:
            r.pass[m]='3';
            lcd.print('*');
            m++;
       break;
            case 4:
            r.pass[m]='4';
            lcd.print('*');
            m++;
       break;
            case 5:
            r.pass[m]='5';
            lcd.print('*');
            m++;
       break;
            case 6:
            r.pass[m]='6';
            lcd.print('*');
            m++;
       break;
            case 8:
            r.pass[m]='7';
            lcd.print('*');
            m++;
       break;
            case 9:
            r.pass[m]='8';
            lcd.print('*');
            m++;
       break;
            case 10:
            r.pass[m]='9';
            lcd.print('*');
            m++;
       break;
            case 12:
            r.pass[m]='*';
            lcd.print('*');
            m++;
       break;
            case 13:
            r.pass[m]='0';
            lcd.print('*');
            m++;
       break;
            case 14:
            r.pass[m]='#';
            lcd.print('*');
            m++;
       break;
            default:
            ;
}       
  }
 }
 lcd.clear();
  k=0;m=0;
lcd.setCursor(0,0);
 
 for(int i=0;i<4 ;i++){
 if(s.pass[i]!=r.pass[i]){
   k=1;
   break;
 }
 }
 m=0;
 if(k==1){
   lcd.clear();
  lcd.print("WrongPassword");
   delay(2000);
 menu_main();
 handler_main();
 }else{
   lcd.print("EnterNewCapacity");
lcd.setCursor(0,1);
  while(1){
   if(m==4)
  break;
  if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
    switch (keypad())  //switch used to specify which button
   {
            case 0:
            r.capacity[m]='1';
            lcd.print('1');
            m++;
       break;  
            case 1:
            r.capacity[m]='2';
            lcd.print('2');
            m++;
       break;
            case 2:
            r.capacity[m]='3';
            lcd.print('3');
            m++;
       break;
            case 4:
            r.capacity[m]='4';
            lcd.print('4');
            m++;
       break;
            case 5:
            r.capacity[m]='5';
            lcd.print('5');
            m++;
       break;
            case 6:
            r.capacity[m]='6';
            lcd.print('6');
            m++;
       break;
            case 8:
            r.capacity[m]='7';
            lcd.print('7');
            m++;
       break;
            case 9:
            r.capacity[m]='8';
            lcd.print('8');
            m++;
       break;
            case 10:
            r.capacity[m]='9';
            lcd.print('9');
            m++;
       break;
            case 13:
            r.capacity[m]='0';
            lcd.print('0');
            m++;
       break;
            default:
            ;
}       
  }
 }
         eeprom_write_block((const void*)&r, (void*)0, sizeof(r));
         lcd.clear();
         lcd.print("Capacity Changed");
         delay(2000);
 }
 
 
}

void change_mob(){
  eeprom_read_block((void*)&s, (void*)0, sizeof(s));
  lcd.clear();
  k=0;m=0;
lcd.setCursor(0,0);
lcd.print("Enter Password");
lcd.setCursor(0,1);
 for(int i=0;i<10;i++)
   r.mobile_number[i]='0';
  for(int i=0;i<4;i++)
   r.pass[i]=s.pass[i];
  for(int i=0;i<4;i++)
   r.capacity[i]=s.capacity[i];
 
 while(1){
 
   if(m==4)
  break;
  if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
    switch (keypad())  //switch used to specify which button
   {
            case 0:
            r.pass[m]='1';
            lcd.print('*');
            m++;
       break;  
            case 1:
            r.pass[m]='2';
            lcd.print('*');
            m++;
       break;
            case 2:
            r.pass[m]='3';
            lcd.print('*');
            m++;
       break;
            case 4:
            r.pass[m]='4';
            lcd.print('*');
            m++;
       break;
            case 5:
            r.pass[m]='5';
            lcd.print('*');
            m++;
       break;
            case 6:
            r.pass[m]='6';
            lcd.print('*');
            m++;
       break;
            case 8:
            r.pass[m]='7';
            lcd.print('*');
            m++;
       break;
            case 9:
            r.pass[m]='8';
            lcd.print('*');
            m++;
       break;
            case 10:
            r.pass[m]='9';
            lcd.print('*');
            m++;
       break;
            case 12:
            r.pass[m]='*';
            lcd.print('*');
            m++;
       break;
            case 13:
            r.pass[m]='0';
            lcd.print('*');
            m++;
       break;
            case 14:
            r.pass[m]='#';
            lcd.print('*');
            m++;
       break;
            default:
            ;
}       
  }
 }
 lcd.clear();
  k=0;m=0;
lcd.setCursor(0,0);
 
 for(int i=0;i<4 ;i++){
 if(s.pass[i]!=r.pass[i]){
   k=1;
   break;
 }
 }
 m=0;
 if(k==1){
   lcd.clear();
  lcd.print("WrongPassword");
   delay(2000);
 menu_main();
 handler_main();
 }else{
   lcd.print("EnterNewContact");
lcd.setCursor(0,1);
  while(1){
   if(m==10)
  break;
  if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
    switch (keypad())  //switch used to specify which button
   {
            case 0:
            r.mobile_number[m]='1';
            lcd.print('1');
            m++;
       break;  
            case 1:
            r.mobile_number[m]='2';
            lcd.print('2');
            m++;
       break;
            case 2:
            r.mobile_number[m]='3';
            lcd.print('3');
            m++;
       break;
            case 4:
            r.mobile_number[m]='4';
            lcd.print('4');
            m++;
       break;
            case 5:
            r.mobile_number[m]='5';
            lcd.print('5');
            m++;
       break;
            case 6:
            r.mobile_number[m]='6';
            lcd.print('6');
            m++;
       break;
            case 8:
            r.mobile_number[m]='7';
            lcd.print('7');
            m++;
       break;
            case 9:
            r.mobile_number[m]='8';
            lcd.print('8');
            m++;
       break;
            case 10:
            r.mobile_number[m]='9';
            lcd.print('9');
            m++;
       break;
            case 13:
            r.mobile_number[m]='0';
            lcd.print('0');
            m++;
       break;
            default:
            ;
}       
  }
 }
         eeprom_write_block((const void*)&r, (void*)0, sizeof(r));
         lcd.clear();
         lcd.print("Mobile Updated");
         delay(2000);
 }
 
 
}

void handler_sub(){
  
  up=down=0;
  while(1){
 
if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
switch (keypad())  //switch used to specify which button
   {
            
            case 3:
            if(up!=0){
            up--;
            down--;
            submenu_main(up);
            }
       break;
            case 7:
            if(down!=3)
            {down++;
             up++;
            submenu_main(down);
            }
        break;
            case 11:
            if(down==3)
            return;
            if(down==2){
               change_mob();
               lcd.clear();          
               menu_main();
               handler_main();
            }
            if(down==1){
               change_capacity();
               lcd.clear();          
               menu_main();
               handler_main();
            }
            if(down==0){
               change_password();
               lcd.clear();          
               menu_main();
               handler_main();
            }
       break;
            case 15:
              return;
       break;   
            default:
            ;
}
}
  }
}
void handler_main(){
  
up1=down1=0;
  while(1){
   
if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
switch (keypad())  //switch used to specify which button
   {
            
            case 3:
            if(up1!=0){
            up1--;
            down1--;
            menu_main(up1);
            }
       break;
            case 7:
            if(down1!=1)
            {down1++;
             up1++;
            menu_main(down1);
            }
        break;
            case 11:
            if(down1==0){
              submenu_main();
              handler_sub();
              lcd.clear();
              menu_main(down1);
              
            }
       break;
            case 15:
                return;
       break;   
            default:
            ;
}
}
  }
}

void setup() {
  

  flow_setup();
mySerial.begin(9600);
  /* First disable the timer overflow interrupt while we're configuring */
  TIMSK2 &= ~(1<<TOIE2);

  /* Configure timer2 in normal mode (pure counting, no PWM etc.) */
  TCCR2A &= ~((1<<WGM21) | (1<<WGM20));
  TCCR2B &= ~(1<<WGM22);

  /* Select clock source: internal I/O clock */
  ASSR &= ~(1<<AS2);

  /* Disable Compare Match A interrupt enable (only want overflow) */
  TIMSK2 &= ~(1<<OCIE2A);

  /* Now configure the prescaler to CPU clock divided by 128 */
  TCCR2B |= (1<<CS22)  | (1<<CS20); // Set bits
  TCCR2B &= ~(1<<CS21);             // Clear bit

  /* We need to calculate a proper value to load the timer counter.
   * The following loads the value 131 into the Timer 2 counter register
   * The math behind this is:
   * (CPU frequency) / (prescaler value) = 125000 Hz = 8us.
   * (desired period) / 8us = 125.
   * MAX(uint8) + 1 - 125 = 131;
   */
  /* Save value globally for later reload in ISR */
  tcnt2 = 131; 

  /* Finally load end enable the timer */
    for(byte i=0;i<rows;i++)  
  {
  pinMode(Output[i],OUTPUT);
  }
  for(byte s=0;s<columns;s++)  
  {
    pinMode(Input[s],INPUT_PULLUP);
  }
  for(int i=0;i<10;i++)
   r.mobile_number[i]='0';
  for(int i=0;i<4;i++)
   r.pass[i]='0';
  for(int i=0;i<4;i++)
   r.capacity[i]='0';
  
  // declare pin 9 to be an output:
  pinMode(8, OUTPUT);  
  analogWrite(8, 50);   
  // set up the LCD's number of columns and rows: 
  lcd.begin(16, 4);
  // Print a message to the LCD.
  lcd.setCursor(3, 0);
  lcd.print("Automated");
   lcd.setCursor(5, 1);
  lcd.print("Water");
  lcd.setCursor(-2, 2);
  lcd.print("Distribution");
  lcd.setCursor(0, 3);
  lcd.print("System");
  delay(3000);
  lcd.clear();
  
  
 
  eeprom_read_block((void*)&s, (void*)0, sizeof(s));

 
 for(int i=0;i<10 ;i++){
 if(s.mobile_number[i]!=r.mobile_number[i]){
   j=1;
   break;
 }  
 }
 
 for(int i=0;i<4 ;i++){
 if(s.pass[i]!=r.pass[i]){
   k=1;
   break;
 }  
 }
 for(int i=0;i<4 ;i++){
 if(s.capacity[i]!=r.capacity[i]){
   l=1;
   break;
 }  
 }
if(k==0 && j==0 && l==0){
  lcd.setCursor(0,0);
    lcd.print("Enter Password:");
 lcd.setCursor(0,1); 
 while(1){
   if(m==4)
  break;
  if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
    switch (keypad())  //switch used to specify which button
   {
            case 0:
            r.pass[m]='1';
            lcd.print('*');
            m++;
       break;  
            case 1:
            r.pass[m]='2';
            lcd.print('*');
            m++;
       break;
            case 2:
            r.pass[m]='3';
            lcd.print('*');
            m++;
       break;
            case 4:
            r.pass[m]='4';
            lcd.print('*');
            m++;
       break;
            case 5:
            r.pass[m]='5';
            lcd.print('*');
            m++;
       break;
            case 6:
            r.pass[m]='6';
            lcd.print('*');
            m++;
       break;
            case 8:
            r.pass[m]='7';
            lcd.print('*');
            m++;
       break;
            case 9:
            r.pass[m]='8';
            lcd.print('*');
            m++;
       break;
            case 10:
            r.pass[m]='9';
            lcd.print('*');
            m++;
       break;
            case 12:
            r.pass[m]='*';
            lcd.print('*');
            m++;
       break;
            case 13:
            r.pass[m]='0';
            lcd.print('*');
            m++;
       break;
            case 14:
            r.pass[m]='#';
            lcd.print('*');
            m++;
       break;
            default:
            ;
}       
  }
    
  }
  delay(800);
  m=0;
  lcd.clear();
  lcd.setCursor(0,0);
    lcd.print("Enter Capacity:");
 lcd.setCursor(0,1); 
 while(1){
   if(m==4)
  break;
  if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
    switch (keypad())  //switch used to specify which button
   {
            case 0:
            r.capacity[m]='1';
            lcd.print('1');
            m++;
       break;  
            case 1:
            r.capacity[m]='2';
            lcd.print('2');
            m++;
       break;
            case 2:
            r.capacity[m]='3';
            lcd.print('3');
            m++;
       break;
            case 4:
            r.capacity[m]='4';
            lcd.print('4');
            m++;
       break;
            case 5:
            r.capacity[m]='5';
            lcd.print('5');
            m++;
       break;
            case 6:
            r.capacity[m]='6';
            lcd.print('6');
            m++;
       break;
            case 8:
            r.capacity[m]='7';
            lcd.print('7');
            m++;
       break;
            case 9:
            r.capacity[m]='8';
            lcd.print('8');
            m++;
       break;
            case 10:
            r.capacity[m]='9';
            lcd.print('9');
            m++;
       break;
            case 13:
            r.capacity[m]='0';
            lcd.print('0');
            m++;
       break;
            default:
            ;
}       
  }

  }
  delay(800);
  m=0;
  lcd.clear();
  lcd.setCursor(0,0);
    lcd.print("Enter Phone no.:");
 lcd.setCursor(0,1); 
 while(1){
   if(m==10)
  break;
  if(millis()-kdelay>period) //used to make non-blocking delay
  {
    kdelay=millis();  //capture time from millis function
    switch (keypad())  //switch used to specify which button
   {
            case 0:
            r.mobile_number[m]='1';
            lcd.print('1');
            m++;
       break;  
            case 1:
            r.mobile_number[m]='2';
            lcd.print('2');
            m++;
       break;
            case 2:
            r.mobile_number[m]='3';
            lcd.print('3');
            m++;
       break;
            case 4:
            r.mobile_number[m]='4';
            lcd.print('4');
            m++;
       break;
            case 5:
            r.mobile_number[m]='5';
            lcd.print('5');
            m++;
       break;
            case 6:
            r.mobile_number[m]='6';
            lcd.print('6');
            m++;
       break;
            case 8:
            r.mobile_number[m]='7';
            lcd.print('7');
            m++;
       break;
            case 9:
            r.mobile_number[m]='8';
            lcd.print('8');
            m++;
       break;
            case 10:
            r.mobile_number[m]='9';
            lcd.print('9');
            m++;
       break;
            case 13:
            r.mobile_number[m]='0';
            lcd.print('0');
            m++;
       break;
            default:
            ;
}       
  }

  }
  eeprom_write_block((const void*)&r, (void*)0, sizeof(r));
 delay(800);
 }

Dump:detachInterrupt(digitalPinToInterrupt(20));
menu_main(); 
handler_main();  
eeprom_read_block((void*)&s, (void*)0, sizeof(s));
TCNT2 = tcnt2;
TIMSK2 |= (1<<TOIE2);
ml=0;
for(int i=0;i<4;++i)
 ml=ml*10 + s.capacity[i] - '0';

attachInterrupt(digitalPinToInterrupt(20), pulseCounter, FALLING); 
while(1)
{
if(toggle==1){
  
break;
}
else
{

lcd.clear();
lcd.setCursor(0,0);
lcd.print("Flow is:");
lcd.print(.001*totalMilliLitres);
lcd.setCursor(0,3);
lcd.print(po);
gsm_loop();
flow_loop();
ph_loop();
}
}

TIMSK2 &= ~(1<<TOIE2);
toggle=0;
goto Dump;
}

ISR(TIMER2_OVF_vect) {
  /* Reload the timer */
  TCNT2 = tcnt2;
  /* Write to a digital pin so that we can confirm our timer */
  switch (keypad())  //switch used to specify which button
   {
            case 15:
            toggle=!toggle;
            break;   
            default:
            ;
    }

   
}


void loop() {
  // put your main code here, to run repeatedly:

}
